# OCR Vision Pro Android

Java Android application using offline Tesseract OCR (English traineddata bundled at CI build time), ZXing multi-format QR/barcode decoding, CameraX preview/capture/live frame analysis, image preprocessing toggles, local settings, SQLite scan history and text sharing.

## Build workflow
The GitHub Actions workflow downloads `eng.traineddata` during build, bundles it into the APK, runs tests, builds the debug APK and uploads `OCR-Vision-Pro-debug-apk`. The installed app recognizes English offline.

## Important scope and limitations
This is a functional upgraded baseline, not the full enterprise feature set from the specification. Tesseract replaces the broken homemade glyph-template recognizer. It handles broad printed-font variation but cannot guarantee all fonts, scripts, handwriting or distorted images. The initial app provides full-frame scanning; ROI editor/polygon tools, per-ROI rules, PP-OCRv6 ONNX runtime/models, GPU inference, PDF/CSV/JSON export, advanced OpenCV operators and multilingual models remain future implementation work. The ROI switch is currently a placeholder and must not be treated as functional.

PaddleOCR's official PP-OCRv6 Android deployment currently documents ONNX Runtime and model assets. Those model files and model-specific pre/postprocessing must be integrated separately; this project does not falsely label Tesseract as PaddleOCR.

## Dependencies
Tesseract tess-two, ZXing core, CameraX, OpenCV Android AAR. English model: tessdata_fast; check upstream model licensing before redistribution.
