package com.example.offlineocr;
import android.content.*;import android.database.*;import android.database.sqlite.*;import java.util.*;
public class ScanHistoryDb extends SQLiteOpenHelper {
 public ScanHistoryDb(Context c){super(c,"scan_history.db",null,1);}
 public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE scans(id INTEGER PRIMARY KEY AUTOINCREMENT,created TEXT,ocr TEXT,code TEXT,confidence INTEGER)");}
 public void onUpgrade(SQLiteDatabase d,int o,int n){}
 public void add(String date,String text,String code,int confidence){ContentValues v=new ContentValues();v.put("created",date);v.put("ocr",text);v.put("code",code);v.put("confidence",confidence);getWritableDatabase().insert("scans",null,v);}
 public List<String> all(){List<String> a=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT created,ocr,code,confidence FROM scans ORDER BY id DESC LIMIT 200",null)){while(c.moveToNext())a.add(c.getString(0)+"\n"+c.getString(1)+"\n"+c.getString(2)+"\nConfidence: "+c.getInt(3)+"%");}return a;}
 public void clear(){getWritableDatabase().delete("scans",null,null);}
}
