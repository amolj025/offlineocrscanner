package com.example.offlineocr;
import androidx.camera.core.ImageProxy;import java.nio.ByteBuffer;
public class ByteBufferHelper {
 public static void toNv21(ImageProxy.PlaneProxy[] p,int w,int h,byte[] out){
  ByteBuffer y=p[0].getBuffer(),u=p[1].getBuffer(),v=p[2].getBuffer();int pos=0;
  for(int r=0;r<h;r++)for(int c=0;c<w;c++)out[pos++]=y.get(r*p[0].getRowStride()+c*p[0].getPixelStride());
  for(int r=0;r<h/2;r++)for(int c=0;c<w/2;c++){out[pos++]=v.get(r*p[2].getRowStride()+c*p[2].getPixelStride());out[pos++]=u.get(r*p[1].getRowStride()+c*p[1].getPixelStride());}
 }
}
