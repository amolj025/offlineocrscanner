package com.example.offlineocr;
import android.content.Context;
import android.graphics.Bitmap;
import com.googlecode.tesseract.android.TessBaseAPI;
import java.io.*;
public class OcrEngine {
 private final TessBaseAPI api=new TessBaseAPI(); private boolean ready=false;
 public OcrEngine(Context c)throws Exception{
  File base=new File(c.getFilesDir(),"tesseract"), td=new File(base,"tessdata"); if(!td.exists()&&!td.mkdirs())throw new Exception("Cannot create tessdata");
  File model=new File(td,"eng.traineddata");
  if(!model.exists())try(InputStream in=c.getAssets().open("tessdata/eng.traineddata");FileOutputStream out=new FileOutputStream(model)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}
  ready=api.init(base.getAbsolutePath(),"eng"); if(!ready)throw new Exception("Tesseract initialization failed");
  api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO);
 }
 public synchronized Result recognize(Bitmap b,String white,String black){
  if(!ready)return new Result("",0);
  api.setImage(b);
  api.setVariable("tessedit_char_whitelist",white==null?"":white);
  api.setVariable("tessedit_char_blacklist",black==null?"":black);
  String t=api.getUTF8Text(); int c=api.meanConfidence(); api.clear();
  return new Result(t==null?"":t.trim(),c);
 }
 public synchronized void close(){if(ready)api.end();ready=false;}
 public static class Result {public final String text;public final int confidence;Result(String t,int c){text=t;confidence=c;}}
}
