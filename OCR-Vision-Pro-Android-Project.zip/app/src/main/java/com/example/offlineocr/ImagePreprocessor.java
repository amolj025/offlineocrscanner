package com.example.offlineocr;
import android.graphics.Bitmap;
import android.graphics.Color;
public class ImagePreprocessor {
 public static Bitmap process(Bitmap src,boolean gray,boolean contrast,boolean threshold,int cut){
  int w=src.getWidth(),h=src.getHeight();Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);int[] p=new int[w*h];src.getPixels(p,0,w,0,0,w,h);
  for(int i=0;i<p.length;i++){int c=p[i],r=Color.red(c),g=Color.green(c),b=Color.blue(c);if(gray||contrast||threshold){int y=(r*299+g*587+b*114)/1000;if(contrast)y=Math.max(0,Math.min(255,(int)((y-128)*1.35+128)));if(threshold)y=y<cut?0:255;r=g=b=y;}p[i]=Color.argb(Color.alpha(c),r,g,b);}
  out.setPixels(p,0,w,0,0,w,h);return out;
 }
}
