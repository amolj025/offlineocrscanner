package com.example.offlineocr;
import android.content.Context;
import android.content.SharedPreferences;
public class SettingsStore {
 private final SharedPreferences p;
 public SettingsStore(Context c){p=c.getSharedPreferences("ocr_settings",Context.MODE_PRIVATE);}
 public boolean get(String k,boolean d){return p.getBoolean(k,d);}
 public void set(String k,boolean v){p.edit().putBoolean(k,v).apply();}
 public int getInt(String k,int d){return p.getInt(k,d);}
 public void setInt(String k,int v){p.edit().putInt(k,v).apply();}
 public String getString(String k,String d){return p.getString(k,d);}
 public void setString(String k,String v){p.edit().putString(k,v).apply();}
 public void reset(){p.edit().clear().apply();}
}
