# Offline OCR Scanner (Java / Android)

A native Android starter app with camera capture, gallery import, editable/selectable OCR output, and an offline custom OCR prototype.

## OCR engine and limitations
The recognition pipeline is implemented in `OcrEngine.java`:
1. RGB-to-grayscale conversion
2. Otsu global thresholding
3. Horizontal text-line segmentation
4. Vertical character segmentation
5. Glyph normalization to 20x28
6. Local template matching against glyphs rendered using Android's local sans/serif/monospace typefaces

No OCR cloud service, ML Kit, or network call is used at runtime. The app can work offline after installation.

**Prototype limitations:** This is an educational baseline, not production-grade general OCR. It is most likely to work with high-contrast, straight, printed Latin text and simple backgrounds. It does not yet robustly handle handwriting, skew, perspective, curved text, columns, complex layouts, tables, or non-Latin scripts. Template matching may confuse similar characters (for example O/0, I/l/1). A production OCR engine needs stronger segmentation, training data, language models, and confidence calibration.

## Build
Requirements: Android Studio (recommended), JDK 17, Android SDK 35.

1. Open this folder in Android Studio.
2. Allow Gradle sync and SDK component installation.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Command line:
```bash
gradle testDebugUnitTest
gradle assembleDebug
```

## Automated APK build
Push this project to a GitHub repository. The included workflow `.github/workflows/android.yml` builds the debug APK and runs unit tests. Download the `OfflineOCRScanner-debug-apk` artifact from the completed GitHub Actions run.

## Suggested test images
Use a well-lit, high-resolution image of a single line or short paragraph of black printed Latin text on a white background. Keep the page flat, text horizontal, and camera in focus.
