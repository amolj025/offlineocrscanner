package com.example.offlineocr;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import java.util.ArrayList;
import java.util.List;

/**
 * Small, fully local classical OCR prototype.
 * Pipeline: grayscale -> Otsu threshold -> line segmentation -> character segmentation
 * -> normalized glyph template matching. Templates are rendered locally with Android fonts.
 *
 * Best suited to clean, high-contrast, horizontally aligned printed text.
 * This is not a production-grade multilingual OCR engine.
 */
public class OcrEngine {
    static final int W = 20, H = 28;
    private static final String ALPHABET =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,:;!?-_/()'\"+%#";
    private final List<Template> templates = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

    public OcrEngine() { buildTemplates(); }

    public String recognize(Bitmap source) {
        if (source == null) return "";
        Bitmap bitmap = resizeIfNeeded(source, 1800);
        int w = bitmap.getWidth(), h = bitmap.getHeight();
        int[] pixels = new int[w * h];
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h);
        int threshold = otsu(pixels);
        boolean[] ink = new boolean[pixels.length];
        for (int i = 0; i < pixels.length; i++) {
            int c = pixels[i];
            int gray = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000;
            ink[i] = gray < threshold;
        }

        List<int[]> lines = findRuns(ink, w, h, true);
        StringBuilder output = new StringBuilder();
        for (int[] line : lines) {
            List<int[]> chars = findRuns(ink, w, line[0], line[1], false);
            int previousRight = -1;
            for (int[] ch : chars) {
                int left = ch[0], right = ch[1];
                if (previousRight >= 0 && left - previousRight > Math.max(3, (right-left)/2))
                    output.append(' ');
                boolean[][] glyph = crop(ink, w, line[0], line[1], left, right);
                Match match = classify(normalize(glyph));
                output.append(match.score > 0.58 ? '?' : match.character);
                previousRight = right;
            }
            if (output.length() > 0) output.append('\n');
        }
        return output.toString().trim();
    }

    private Bitmap resizeIfNeeded(Bitmap src, int max) {
        int largest = Math.max(src.getWidth(), src.getHeight());
        if (largest <= max) return src;
        float scale = max / (float) largest;
        return Bitmap.createScaledBitmap(src, Math.round(src.getWidth()*scale),
            Math.round(src.getHeight()*scale), true);
    }

    private int otsu(int[] pixels) {
        int[] hist = new int[256];
        for (int c : pixels) {
            int g = (Color.red(c)*299 + Color.green(c)*587 + Color.blue(c)*114)/1000;
            hist[g]++;
        }
        int total = pixels.length, sum = 0;
        for (int i=0;i<256;i++) sum += i*hist[i];
        int sumB=0, weightB=0; double max=-1; int threshold=150;
        for (int t=0;t<256;t++) {
            weightB += hist[t]; if (weightB==0) continue;
            int weightF=total-weightB; if (weightF==0) break;
            sumB += t*hist[t];
            double mB=sumB/(double)weightB, mF=(sum-sumB)/(double)weightF;
            double between=weightB*(double)weightF*(mB-mF)*(mB-mF);
            if (between>max) { max=between; threshold=t; }
        }
        return Math.max(60, Math.min(220, threshold));
    }

    private List<int[]> findRuns(boolean[] ink, int w, int h, boolean horizontal) {
        return findRuns(ink, w, 0, h, horizontal);
    }

    private List<int[]> findRuns(boolean[] ink, int w, int y0, int y1, boolean horizontal) {
        int span = horizontal ? y1-y0 : w;
        int cross = horizontal ? w : y1-y0;
        List<int[]> runs = new ArrayList<>();
        boolean active=false; int start=0;
        for (int p=0;p<span;p++) {
            int count=0;
            for (int q=0;q<cross;q++) {
                int x=horizontal?q:p, y=horizontal?y0+p:y0+q;
                if (ink[y*w+x]) count++;
            }
            boolean on=count>0;
            if (on&&!active) { start=p; active=true; }
            if (!on&&active) {
                if (p-start>=1) runs.add(horizontal?new int[]{y0+start,y0+p}:new int[]{start,p});
                active=false;
            }
        }
        if (active) runs.add(horizontal?new int[]{y0+start,y0+span}:new int[]{start,span});
        return runs;
    }

    private boolean[][] crop(boolean[] ink,int w,int top,int bottom,int left,int right) {
        int l=right,r=left,t=bottom,b=top;
        for(int y=top;y<bottom;y++) for(int x=left;x<right;x++) if(ink[y*w+x]){
            l=Math.min(l,x); r=Math.max(r,x+1); t=Math.min(t,y); b=Math.max(b,y+1);
        }
        boolean[][] out=new boolean[Math.max(1,b-t)][Math.max(1,r-l)];
        for(int y=t;y<b;y++) for(int x=l;x<r;x++) out[y-t][x-l]=ink[y*w+x];
        return out;
    }

    static boolean[] normalize(boolean[][] glyph) {
        int gh=glyph.length, gw=glyph[0].length;
        int max=Math.max(gw,gh);
        int ox=(W-max*W/max)/2, oy=(H-max*H/max)/2;
        boolean[] out=new boolean[W*H];
        for(int y=0;y<H;y++) for(int x=0;x<W;x++) {
            int sx=(int)((x-ox)*max/(double)W), sy=(int)((y-oy)*max/(double)H);
            if(sx>=0&&sx<gw&&sy>=0&&sy<gh) out[y*W+x]=glyph[sy][sx];
        }
        return out;
    }

    private void buildTemplates() {
        String[] fonts={"sans","serif","monospace"};
        for(char c:ALPHABET.toCharArray()) for(String family:fonts) for(int style:new int[]{Typeface.NORMAL,Typeface.BOLD}) {
            Bitmap b=Bitmap.createBitmap(64,64,Bitmap.Config.ARGB_8888);
            Canvas canvas=new Canvas(b); canvas.drawColor(Color.WHITE);
            paint.setColor(Color.BLACK); paint.setTextSize(48);
            Typeface tf=Typeface.create(family,style); paint.setTypeface(tf);
            paint.setTextAlign(Paint.Align.CENTER);
            Paint.FontMetrics fm=paint.getFontMetrics();
            float baseline=32-(fm.ascent+fm.descent)/2;
            canvas.drawText(String.valueOf(c),32,baseline,paint);
            int[] px=new int[64*64]; b.getPixels(px,0,64,0,0,64,64);
            int minX=64,minY=64,maxX=0,maxY=0;
            for(int y=0;y<64;y++)for(int x=0;x<64;x++)if(Color.red(px[y*64+x])<100){
                minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);
            }
            if(maxX>minX&&maxY>minY){
                boolean[][] g=new boolean[maxY-minY+1][maxX-minX+1];
                for(int y=minY;y<=maxY;y++)for(int x=minX;x<=maxX;x++)
                    g[y-minY][x-minX]=Color.red(px[y*64+x])<150;
                templates.add(new Template(c,normalize(g)));
            }
            b.recycle();
        }
    }

    private Match classify(boolean[] glyph) {
        char best='?'; double score=Double.MAX_VALUE;
        for(Template t:templates) {
            int diff=0;
            for(int i=0;i<glyph.length;i++) if(glyph[i]!=t.bits[i]) diff++;
            double d=diff/(double)glyph.length;
            if(d<score){score=d;best=t.c;}
        }
        return new Match(best,score);
    }

    private static class Template {
        final char c; final boolean[] bits;
        Template(char c,boolean[] bits){this.c=c;this.bits=bits;}
    }
    private static class Match {
        final char character; final double score;
        Match(char c,double s){character=c;score=s;}
    }
}
