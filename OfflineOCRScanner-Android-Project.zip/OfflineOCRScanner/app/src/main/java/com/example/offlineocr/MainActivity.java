package com.example.offlineocr;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private PreviewView previewView;
    private ImageCapture imageCapture;
    private TextView status, result;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final OcrEngine ocr = new OcrEngine();

    private final ActivityResultLauncher<String> gallery =
        registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri != null) loadUri(uri);
        });

    private final ActivityResultLauncher<String> cameraPermission =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) startCamera();
            else status.setText("Camera permission denied. You can still select an image.");
        });

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) startCamera();
        else cameraPermission.launch(Manifest.permission.CAMERA);
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(18, 18, 18, 12);
        page.setBackgroundColor(0xFFF7F8FA);

        TextView title = new TextView(this);
        title.setText("Offline OCR Scanner");
        title.setTextSize(24); title.setTextColor(0xFF17212B);
        title.setPadding(0, 4, 0, 12);
        page.addView(title);

        status = new TextView(this);
        status.setText("Ready • Recognition runs on this device");
        status.setTextSize(13); status.setTextColor(0xFF526170);
        page.addView(status);

        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.1f);
        previewParams.topMargin = 12;
        page.addView(previewView, previewParams);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        Button capture = button("Capture & OCR");
        Button choose = button("Choose image");
        actions.addView(capture, new LinearLayout.LayoutParams(0, 52, 1));
        actions.addView(choose, new LinearLayout.LayoutParams(0, 52, 1));
        page.addView(actions);

        TextView label = new TextView(this);
        label.setText("RECOGNIZED TEXT");
        label.setTextSize(12); label.setTextColor(0xFF526170);
        label.setPadding(0, 14, 0, 5);
        page.addView(label);

        result = new TextView(this);
        result.setText("Your recognized text will appear here.");
        result.setTextIsSelectable(true);
        result.setTextSize(16); result.setTextColor(0xFF17212B);
        result.setPadding(12, 12, 12, 12);
        result.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams resultParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.8f);
        page.addView(result, resultParams);

        Button copy = button("Copy text");
        page.addView(copy);
        copy.setOnClickListener(v -> {
            android.content.ClipboardManager cm =
                (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("OCR text", result.getText()));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
        });
        capture.setOnClickListener(v -> captureImage());
        choose.setOnClickListener(v -> gallery.launch("image/*"));
        setContentView(page);
    }

    private Button button(String text) {
        Button b = new Button(this); b.setText(text); return b;
    }

    private void startCamera() {
        final com.google.common.util.concurrent.ListenableFuture<ProcessCameraProvider> future =
            ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                imageCapture = new ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build();
                provider.unbindAll();
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA,
                    preview, imageCapture);
                status.setText("Camera ready • Point at clear, printed text");
            } catch (Exception e) {
                status.setText("Camera unavailable: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void captureImage() {
        if (imageCapture == null) {
            Toast.makeText(this, "Camera is not ready", Toast.LENGTH_SHORT).show(); return;
        }
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, "offline_ocr_" + System.currentTimeMillis() + ".jpg");
        values.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
        ImageCapture.OutputFileOptions options = new ImageCapture.OutputFileOptions.Builder(
            getContentResolver(), MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build();
        imageCapture.takePicture(options, ContextCompat.getMainExecutor(this),
            new ImageCapture.OnImageSavedCallback() {
                @Override public void onImageSaved(ImageCapture.OutputFileResults output) {
                    if (output.getSavedUri() != null) loadUri(output.getSavedUri());
                }
                @Override public void onError(ImageCaptureException exception) {
                    status.setText("Capture failed: " + exception.getMessage());
                }
            });
    }

    private void loadUri(Uri uri) {
        status.setText("Loading image…");
        executor.execute(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                Bitmap bitmap = BitmapFactory.decodeStream(in);
                if (bitmap == null) throw new IllegalArgumentException("Unsupported image");
                String text = ocr.recognize(bitmap);
                runOnUiThread(() -> {
                    result.setText(text.isEmpty() ? "No text detected. Try a sharper, closer image." : text);
                    status.setText("Finished • Offline custom OCR");
                });
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Could not read image: " + e.getMessage()));
            }
        });
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
