package com.example.offlineocr;

import org.junit.Test;
import static org.junit.Assert.*;

public class OcrEngineTest {
    @Test public void normalizedGlyphHasExpectedDimensions() {
        boolean[][] glyph = new boolean[12][8];
        for (int y=1;y<11;y++) for(int x=2;x<6;x++) glyph[y][x]=true;
        boolean[] normalized = OcrEngine.normalize(glyph);
        assertEquals(20*28, normalized.length);
    }
    @Test public void normalizedGlyphIsNotEmpty() {
        boolean[][] glyph = new boolean[10][10];
        for(int i=1;i<9;i++) glyph[i][i]=true;
        boolean[] normalized = OcrEngine.normalize(glyph);
        boolean found=false;
        for(boolean bit:normalized) found |= bit;
        assertTrue(found);
    }
}
